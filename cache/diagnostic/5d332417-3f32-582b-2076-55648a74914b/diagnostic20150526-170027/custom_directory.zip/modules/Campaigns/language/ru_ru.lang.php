<?php
// created: 2015-05-15 14:39:15
$mod_strings = array (
  'LBL_CAMPAIGN_CONTENT' => 'Метраж',
);