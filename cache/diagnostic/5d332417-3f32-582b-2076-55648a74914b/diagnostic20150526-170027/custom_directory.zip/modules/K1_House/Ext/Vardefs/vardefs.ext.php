<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2015-05-21 16:31:25
$dictionary["K1_House"]["fields"]["k1_house_notes"] = array (
  'name' => 'k1_house_notes',
  'type' => 'link',
  'relationship' => 'k1_house_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'side' => 'right',
  'vname' => 'LBL_K1_HOUSE_NOTES_FROM_NOTES_TITLE',
);


// created: 2015-05-26 10:41:37
$dictionary["K1_House"]["fields"]["k1_office_k1_house"] = array (
  'name' => 'k1_office_k1_house',
  'type' => 'link',
  'relationship' => 'k1_office_k1_house',
  'source' => 'non-db',
  'module' => 'K1_office',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_K1_OFFICE_K1_HOUSE_FROM_K1_OFFICE_TITLE',
);

?>