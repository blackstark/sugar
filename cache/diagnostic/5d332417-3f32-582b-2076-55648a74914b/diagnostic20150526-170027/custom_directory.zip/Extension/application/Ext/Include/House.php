<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['K1_House'] = 'K1_House';
$beanFiles['K1_House'] = 'modules/K1_House/K1_House.php';
$moduleList[] = 'K1_House';

?>