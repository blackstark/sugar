<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/k1_office_k1_houseMetaData.php');

?>