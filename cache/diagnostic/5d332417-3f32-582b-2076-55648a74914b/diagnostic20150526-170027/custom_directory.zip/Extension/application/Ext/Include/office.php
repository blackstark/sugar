<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['K1_office'] = 'K1_office';
$beanFiles['K1_office'] = 'modules/K1_office/K1_office.php';
$moduleList[] = 'K1_office';

?>