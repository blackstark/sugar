<?php 
 //WARNING: The contents of this file are auto-generated

 
 //WARNING: The contents of this file are auto-generated
$beanList['K1_House'] = 'K1_House';
$beanFiles['K1_House'] = 'modules/K1_House/K1_House.php';
$moduleList[] = 'K1_House';


 
 //WARNING: The contents of this file are auto-generated
$beanList['K1_office'] = 'K1_office';
$beanFiles['K1_office'] = 'modules/K1_office/K1_office.php';
$moduleList[] = 'K1_office';


?>