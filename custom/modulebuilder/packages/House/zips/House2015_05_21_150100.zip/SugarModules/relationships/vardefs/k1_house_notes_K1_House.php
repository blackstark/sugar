<?php
// created: 2015-05-21 15:01:00
$dictionary["K1_House"]["fields"]["k1_house_notes"] = array (
  'name' => 'k1_house_notes',
  'type' => 'link',
  'relationship' => 'k1_house_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'side' => 'right',
  'vname' => 'LBL_K1_HOUSE_NOTES_FROM_NOTES_TITLE',
);
