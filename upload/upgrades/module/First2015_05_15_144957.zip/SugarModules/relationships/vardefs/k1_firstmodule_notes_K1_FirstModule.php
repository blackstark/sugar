<?php
// created: 2015-05-15 14:49:57
$dictionary["K1_FirstModule"]["fields"]["k1_firstmodule_notes"] = array (
  'name' => 'k1_firstmodule_notes',
  'type' => 'link',
  'relationship' => 'k1_firstmodule_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'side' => 'right',
  'vname' => 'LBL_K1_FIRSTMODULE_NOTES_FROM_NOTES_TITLE',
);
