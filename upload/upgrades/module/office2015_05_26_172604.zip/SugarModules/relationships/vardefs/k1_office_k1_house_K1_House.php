<?php
// created: 2015-05-26 17:26:04
$dictionary["K1_House"]["fields"]["k1_office_k1_house"] = array (
  'name' => 'k1_office_k1_house',
  'type' => 'link',
  'relationship' => 'k1_office_k1_house',
  'source' => 'non-db',
  'module' => 'K1_office',
  'bean_name' => 'K1_office',
  'side' => 'right',
  'vname' => 'LBL_K1_OFFICE_K1_HOUSE_FROM_K1_OFFICE_TITLE',
);
