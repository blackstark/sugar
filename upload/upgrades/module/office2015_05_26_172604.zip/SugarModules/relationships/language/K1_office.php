<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_K1_OFFICE_K1_HOUSE_FROM_K1_HOUSE_TITLE'] = 'Объекты недвижимости';
