<?php
// created: 2015-05-26 17:31:06
$dictionary["K1_House"]["fields"]["k1_house_k1_office"] = array (
  'name' => 'k1_house_k1_office',
  'type' => 'link',
  'relationship' => 'k1_house_k1_office',
  'source' => 'non-db',
  'module' => 'K1_office',
  'bean_name' => 'K1_office',
  'side' => 'right',
  'vname' => 'LBL_K1_HOUSE_K1_OFFICE_FROM_K1_OFFICE_TITLE',
);
